import os
from werkzeug.utils import secure_filename
from datetime import datetime
from flask import current_app

def save_file(file):
    if not file:
        return None

    upload_folder = current_app.config["UPLOAD_FOLDER"]
    os.makedirs(upload_folder, exist_ok=True)

    filename = secure_filename(file.filename)
    unique = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{filename}"

    path = os.path.join(upload_folder, unique)
    file.save(path)

    return f"uploads/evidence/{unique}"
