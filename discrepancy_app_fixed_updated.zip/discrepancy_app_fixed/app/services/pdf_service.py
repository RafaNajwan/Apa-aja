from io import BytesIO
from reportlab.platypus import *
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm

from app.utils.pdf_components import *


def build_doc():
    buffer = BytesIO()

    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=2*cm,
        leftMargin=2*cm,
        topMargin=1*cm,
        bottomMargin=2*cm
    )

    return buffer, doc


# =================================================
# VERIFICATION PDF
# =================================================
def generate_verification_pdf(v):
    buffer, doc = build_doc()
    styles, normal, heading = get_base_styles()

    elements = []

    elements.append(build_header(
        "DISCREPANCY VERIFICATION REPORT",
        "Laporan Verifikasi Ketidaksesuaian"
    ))

    elements.append(Spacer(1, 20))

    elements.append(Paragraph(f"Customer: {v.customer}", normal))
    elements.append(Paragraph(f"Work Order: {v.work_order}", normal))
    elements.append(Spacer(1, 20))

    elements.append(build_signature())

    doc.build(elements)
    buffer.seek(0)

    return buffer


# =================================================
# REALIZATION PDF
# =================================================
def generate_realization_pdf(r):
    buffer, doc = build_doc()
    styles, normal, heading = get_base_styles()

    elements = []

    elements.append(build_header(
        "DISCREPANCY REALIZATION REPORT",
        "Laporan Realisasi Ketidaksesuaian"
    ))

    elements.append(Spacer(1, 20))

    elements.append(Paragraph(f"Total Amount: Rp {r.total_amount:,.0f}", normal))
    elements.append(build_signature())

    doc.build(elements)
    buffer.seek(0)

    return buffer


# =================================================
# EREPORT PDF
# =================================================
def generate_ereport_pdf(e):
    buffer, doc = build_doc()
    styles, normal, heading = get_base_styles()

    elements = []

    elements.append(build_header(
        "E-REPORTING LAPANGAN",
        "Field Report"
    ))

    elements.append(Spacer(1, 20))

    elements.append(Paragraph(f"Work Order: {e.work_order}", normal))
    elements.append(Paragraph(f"Qty Missing: {e.quantity}", normal))
    elements.append(Paragraph(e.deskripsi or "-", normal))

    doc.build(elements)
    buffer.seek(0)

    return buffer
