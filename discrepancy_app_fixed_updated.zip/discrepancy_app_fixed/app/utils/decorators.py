from functools import wraps
from flask import abort, flash, redirect, url_for
from flask_login import current_user


def driver_required(f):
    """Hanya driver yang bisa akses"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please login to access this page', 'error')
            return redirect(url_for('auth.login'))
        if not current_user.is_driver():
            flash('Akses ditolak. Halaman ini hanya untuk Driver.', 'error')
            abort(403)
        return f(*args, **kwargs)
    return decorated_function


def finance_required(f):
    """Hanya finance yang bisa akses (create/edit/delete)"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please login to access this page', 'error')
            return redirect(url_for('auth.login'))
        if not current_user.is_finance():
            flash('Akses ditolak. Halaman ini hanya untuk Finance.', 'error')
            abort(403)
        return f(*args, **kwargs)
    return decorated_function


def finance_or_accounting_required(f):
    """Finance dan accounting bisa akses (view only untuk accounting)"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please login to access this page', 'error')
            return redirect(url_for('auth.login'))
        if not (current_user.is_finance() or current_user.is_accounting()):
            flash('Akses ditolak. Halaman ini untuk Finance dan Accounting.', 'error')
            abort(403)
        return f(*args, **kwargs)
    return decorated_function


def role_required(*roles):
    """Decorator generik untuk satu atau lebih role"""
    def wrapper(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash('Please login to access this page', 'error')
                return redirect(url_for('auth.login'))
            if current_user.role not in roles:
                flash(f'Akses ditolak. Role yang dibutuhkan: {", ".join(roles)}', 'error')
                abort(403)
            return f(*args, **kwargs)
        return decorated_function
    return wrapper
