from flask import make_response

# ReportLab imports for PDF generation
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from io import BytesIO

def create_pdf_header(company_info=None):
    """
    Create standard PDF header with logo, company info, and title
    
    Args:
        company_info (dict): Contains 'title', 'subtitle'
    
    Returns:
        list: List of ReportLab elements (header, separator)
    """
    from reportlab.lib.styles import ParagraphStyle
    
    elements = []
    
    # Logo
    logo = Image(
        "static/images/logo.png",
        width=2.6*cm,
        height=2.6*cm,
        kind='proportional'
    )
    
    # Company information
    company = Paragraph(
        """
        <b>PT. Grahaprima Suksesamandiri Tbk</b><br/>
        Graha 51 Lt. 3 Jl. Tanah Abang II/57<br/>
        Petojo Selatan, Gambir, Jakarta Pusat 10160<br/>
        T. 021 34832477 | www.grahatrans.com
        """,
        ParagraphStyle(
            "Company",
            fontSize=7.8,
            leading=9.5,
            textColor=colors.HexColor("#374151")
        )
    )
    
    # Title and subtitle
    title_text = company_info.get('title', 'REPORT') if company_info else 'REPORT'
    subtitle_text = company_info.get('subtitle', '') if company_info else ''
    
    title = Paragraph(
        f"<b>{title_text}</b>",
        ParagraphStyle(
            "Title",
            fontSize=17,
            leading=18,
            alignment=2,
            textColor=colors.HexColor("#0891b2"),
            spaceAfter=2
        )
    )
    
    subtitle = Paragraph(
        subtitle_text,
        ParagraphStyle(
            "Subtitle",
            fontSize=9,
            alignment=2,
            textColor=colors.HexColor("#0891b2")
        )
    )
    
    # Title block
    title_block = Table(
        [[title], [subtitle]],
        colWidths=[6.8*cm],
        rowHeights=[2.2*cm, 0.6*cm]
    )
    
    title_block.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ('TOPPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
    ]))
    
    # Header table
    header = Table(
        [[logo, company, title_block]],
        colWidths=[3*cm, 7.2*cm, 6.8*cm],
        rowHeights=[3*cm]
    )
    
    header.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ('TOPPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
    ]))
    
    elements.append(header)
    
    # Blue line separator
    elements.append(Spacer(1, 0.15*cm))
    elements.append(Table(
        [['']],
        colWidths=[17*cm],
        style=[('LINEBELOW', (0, 0), (-1, -1), 2, colors.HexColor('#0891b2'))]
    ))
    elements.append(Spacer(1, 0.35*cm))
    
    return elements


def create_info_table(data, colWidths=None):
    """
    Create a standard information table
    
    Args:
        data (list): List of [label, value] pairs
        colWidths (list): Column widths, defaults to [4*cm, 13*cm]
    
    Returns:
        Table: Styled ReportLab table
    """
    if colWidths is None:
        colWidths = [4*cm, 13*cm]
    
    table = Table(data, colWidths=colWidths)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f9fafb')),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#374151')),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e5e7eb')),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ]))
    
    return table


def create_notes_section(notes_text, normal_style):
    """
    Create a yellow notes/remarks section
    
    Args:
        notes_text (str): The notes content
        normal_style: ReportLab paragraph style
    
    Returns:
        list: List of elements (title and table)
    """
    from reportlab.lib.styles import ParagraphStyle
    
    elements = []
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        fontSize=11,
        textColor=colors.HexColor('#374151'),
        spaceAfter=10,
        spaceBefore=15
    )
    
    notes_title = Paragraph('<b>Catatan / Notes:</b>', heading_style)
    elements.append(notes_title)
    
    notes_data = [[Paragraph(notes_text, normal_style)]]
    notes_table = Table(notes_data, colWidths=[17*cm])
    notes_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#fef3c7')),
        ('LEFTPADDING', (0, 0), (-1, -1), 15),
        ('RIGHTPADDING', (0, 0), (-1, -1), 15),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('LINEABOVE', (0, 0), (0, 0), 3, colors.HexColor('#f59e0b')),
    ]))
    elements.append(notes_table)
    
    return elements


def create_signature_section():
    """
    Create standard signature section
    
    Returns:
        Table: Signature table
    """
    signature_data = [
        ['Verified By', 'Approved By'],
        ['', ''],
        ['', ''],
        ['', ''],
        ['_________________________', '_________________________'],
        ['Staff Finance', 'Finance Manager']
    ]
    
    signature_table = Table(
        signature_data,
        colWidths=[8.5*cm, 8.5*cm],
        rowHeights=[0.8*cm, 1.5*cm, 0.3*cm, 0.3*cm, 0.5*cm, 0.5*cm]
    )
    
    signature_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('FONTSIZE', (0, 4), (-1, 5), 9),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#374151')),
    ]))
    
    return signature_table


def create_pdf_response(buffer, filename):
    """
    Create Flask response for PDF download
    
    Args:
        buffer (BytesIO): PDF buffer
        filename (str): Download filename
    
    Returns:
        Response: Flask response object
    """
    pdf_data = buffer.getvalue()
    buffer.close()
    
    response = make_response(pdf_data)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename={filename}'
    
    return response

def format_idr(value, default='Rp 0'):
    """
    Format number as Indonesian Rupiah (1.000.000) without decimals.
    Accepts int, float, Decimal, or None.
    """
    if value is None:
        return default
    try:
        # pastikan value adalah angka
        value_float = float(value)
        return "Rp " + f"{value_float:,.0f}".replace(",", ".")
    except (ValueError, TypeError):
        return default


