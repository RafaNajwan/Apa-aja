import os
from reportlab.platypus import *
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm


# ======================
# BASE STYLES
# ======================
def get_base_styles():
    styles = getSampleStyleSheet()

    normal = styles["Normal"]
    normal.fontSize = 9

    heading = ParagraphStyle(
        "Heading",
        parent=styles["Heading2"],
        fontSize=11,
        textColor=colors.HexColor("#374151"),
        spaceAfter=10,
        spaceBefore=15
    )

    return styles, normal, heading


# ======================
# HEADER COMPONENT (REUSABLE)
# ======================
def build_header(title_text, subtitle_text):
    logo = Image(
        "static/images/logo.png",
        width=2.6 * cm,
        height=2.6 * cm
    )

    company = Paragraph(
        "<b>PT. Grahaprima Suksesamandiri Tbk</b><br/>"
        "Graha 51 Lt. 3 Jakarta Pusat<br/>www.grahatrans.com",
        ParagraphStyle("Company", fontSize=8)
    )

    title = Paragraph(
        f"<b>{title_text}</b>",
        ParagraphStyle("Title", fontSize=17, alignment=2,
                       textColor=colors.HexColor("#0891b2"))
    )

    subtitle = Paragraph(
        subtitle_text,
        ParagraphStyle("Subtitle", fontSize=9, alignment=2,
                       textColor=colors.HexColor("#0891b2"))
    )

    title_block = Table([[title], [subtitle]])

    header = Table([[logo, company, title_block]],
                   colWidths=[3*cm, 7*cm, 7*cm])

    return header


# ======================
# SIGNATURE COMPONENT
# ======================
def build_signature():
    data = [
        ['Verified By', 'Approved By'],
        ['', ''],
        ['', ''],
        ['____________________', '____________________']
    ]

    return Table(data, colWidths=[8.5*cm, 8.5*cm])
