from flask import Flask
from .extensions import db, login_manager
from config import Config


def create_app():
    app = Flask(
        __name__,
        template_folder="../templates",
        static_folder="../static"
    )

    app.config.from_object(Config)

    db.init_app(app)
    login_manager.init_app(app)

    # Register user_loader
    from .models.user import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    from .routes.ereport_routes import ereport_bp
    from .routes.verification_routes import verification_bp
    from .routes.realization_routes import realization_bp
    from .routes.api_routes import api_bp
    from .routes.auth_routes import auth_bp
    from .routes.dashboard_routes import dashboard_bp
    from .routes.main_routes import main_bp

    app.register_blueprint(ereport_bp)
    app.register_blueprint(verification_bp)
    app.register_blueprint(realization_bp)
    app.register_blueprint(api_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(main_bp)

    with app.app_context():
        db.create_all()

    return app
