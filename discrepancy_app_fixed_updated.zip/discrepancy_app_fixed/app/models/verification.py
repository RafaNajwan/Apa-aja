from datetime import datetime
from sqlalchemy import func, extract
from ..extensions import db

class Verification(db.Model):
    """
    Model untuk Verification Form
    Customer diambil dari EReport, tidak disimpan di sini
    """
    __tablename__ = 'verifications'
    
    id = db.Column(db.Integer, primary_key=True)
    e_report_id = db.Column(db.Integer, db.ForeignKey('e_reports.id'), nullable=False, unique=True)
    
    date = db.Column(db.Date, nullable=False)
    
    # PERBAIKAN: Hapus field customer karena sudah ada di EReport
    # customer = db.Column(db.String(200), nullable=True)  # DIHAPUS
    
    discrepancy_no = db.Column(db.String(100), nullable=True, unique=True)
    work_order = db.Column(db.String(100), nullable=False)
    license_num = db.Column(db.String(50), nullable=True)
    driver_name = db.Column(db.String(200), nullable=True)
    remark = db.Column(db.Text, nullable=True)
    claim_type = db.Column(db.String(50), nullable=True)
    item_name = db.Column(db.String(200), nullable=True)
    quantity = db.Column(db.Integer, nullable=True)
    unit_price = db.Column(db.Numeric(15, 2), nullable=True)
    loss = db.Column(db.Numeric(15, 2), nullable=True)
    total_price = db.Column(db.Numeric(15, 2), nullable=True)
    
    status = db.Column(db.String(20), default='unrealized')
    is_realized = db.Column(db.Boolean, default=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship dengan Realization
    realization = db.relationship('Realization', back_populates='verification', uselist=False, cascade='all, delete-orphan')
    
    # Property untuk mengakses customer dari e_report
    @property
    def customer(self):
        """Get customer from related e_report"""
        return self.e_report.customer if self.e_report else None
    
    @staticmethod
    def generate_discrepancy_no(date):
        from sqlalchemy import func, extract
        
        date_str = date.strftime('%d/%m/%Y')
        
        count = db.session.query(func.count(Verification.id)).filter(
            extract('day', Verification.date) == date.day,
            extract('month', Verification.date) == date.month,
            extract('year', Verification.date) == date.year
        ).scalar()
        
        seq_num = str(count + 1).zfill(2)
        
        return f"DP/{date_str}/{seq_num}"