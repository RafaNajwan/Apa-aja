from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from ..extensions import db


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    full_name = db.Column(db.String(200), nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='driver')  # driver, finance, accounting
    is_active = db.Column(db.Boolean, default=True)
    last_login = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def is_driver(self):
        """Driver: hanya bisa membuat dan melihat e-report"""
        return self.role == 'driver'

    def is_finance(self):
        """Finance: membuat verification dan realization, melihat semua"""
        return self.role == 'finance'

    def is_accounting(self):
        """Accounting: hanya bisa melihat semua (read-only)"""
        return self.role == 'accounting'

    def can_create_ereport(self):
        """Hanya driver yang bisa membuat e-report"""
        return self.role == 'driver'

    def can_view_ereport(self):
        """Semua role bisa melihat e-report"""
        return self.role in ('driver', 'finance', 'accounting')

    def can_manage_verification(self):
        """Hanya finance yang bisa membuat/edit verification"""
        return self.role == 'finance'

    def can_view_verification(self):
        """Finance dan accounting bisa melihat verification"""
        return self.role in ('finance', 'accounting')

    def can_manage_realization(self):
        """Hanya finance yang bisa membuat/edit realization"""
        return self.role == 'finance'

    def can_view_realization(self):
        """Finance dan accounting bisa melihat realization"""
        return self.role in ('finance', 'accounting')

    def __repr__(self):
        return f'<User {self.username} ({self.role})>'
