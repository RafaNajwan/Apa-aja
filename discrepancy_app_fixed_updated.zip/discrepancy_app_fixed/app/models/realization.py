from datetime import datetime
from ..extensions import db

class Realization(db.Model):
    """
    Model untuk Realization Form
    """
    __tablename__ = 'realizations'
    
    id = db.Column(db.Integer, primary_key=True)
    verification_id = db.Column(db.Integer, db.ForeignKey('verifications.id'), nullable=False, unique=True)
    
    date = db.Column(db.Date, nullable=False)
    discrepancy_no = db.Column(db.String(100), nullable=True)
    working_order = db.Column(db.String(100), nullable=False)
    payment_method = db.Column(db.String(50), nullable=True)
    class_payment = db.Column(db.String(50), nullable=True)
    claim_amount = db.Column(db.String(100), nullable=True)
    debit_no = db.Column(db.String(100), nullable=True)
    realization_amount = db.Column(db.Numeric(15, 2), nullable=True)
    ppn = db.Column(db.Numeric(15, 2), nullable=True)
    total_amount = db.Column(db.Numeric(15, 2), nullable=True)
    
    status = db.Column(db.String(20), default='completed')
    is_verified = db.Column(db.Boolean, default=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # PERBAIKAN: Tambahkan back_populates
    verification = db.relationship('Verification', back_populates='realization')
