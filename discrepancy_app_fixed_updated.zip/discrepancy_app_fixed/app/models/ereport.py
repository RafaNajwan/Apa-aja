from datetime import datetime
from ..extensions import db

class EReportItem(db.Model):
    __tablename__ = "e_report_items"

    id = db.Column(db.Integer, primary_key=True)
    ereport_id = db.Column(db.Integer, db.ForeignKey("e_reports.id"), nullable=False)
    detail_barang = db.Column(db.String(200), nullable=False)
    jumlah = db.Column(db.Integer, nullable=False)

class EReport(db.Model):
    __tablename__ = "e_reports"

    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    
    # Field customer ada di EReport
    customer = db.Column(db.String(200), nullable=True)
    
    work_order = db.Column(db.String(100), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    deskripsi = db.Column(db.Text)
    evidence = db.Column(db.String(255))

    status = db.Column(db.String(20), default="pending")
    is_verified = db.Column(db.Boolean, default=False)
    realize_status = db.Column(db.String(20), default="unrealized")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)

    items = db.relationship(
        "EReportItem",
        backref="ereport",
        cascade="all, delete-orphan",
        lazy=True
    )

    verification = db.relationship(
        "Verification",
        backref="e_report",
        uselist=False,
        cascade="all, delete-orphan"
    )

    def to_dict(self):
        return {
            "id": self.id,
            "customer": self.customer,
            "work_order": self.work_order,
            "quantity": self.quantity,
            "status": self.status
        }