from datetime import datetime
from ..extensions import db

class SavedDraft(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    draft_type = db.Column(db.String(20))
    data = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
