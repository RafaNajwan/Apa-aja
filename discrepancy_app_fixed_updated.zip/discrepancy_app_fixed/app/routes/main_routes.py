from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user
from ..models import EReport, Verification, Realization

main_bp = Blueprint('main', __name__)


@main_bp.route('/')
def index():
    """Home page - redirect to dashboard if logged in, else login"""
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return redirect(url_for('auth.login'))


@main_bp.route('/dashboard')
@login_required
def dashboard():
    """Dashboard - role-based view"""
    
    # Get statistics based on role
    if current_user.is_driver():
        # Driver stats
        total_reports = EReport.query.count()
        my_reports = EReport.query.count()  # TODO: filter by driver if needed
        pending_reports = EReport.query.filter_by(status='pending').count()
        verified_reports = EReport.query.filter_by(is_verified=True).count()
        
        stats = {
            'total_reports': total_reports,
            'my_reports': my_reports,
            'pending': pending_reports,
            'verified': verified_reports
        }
        
        # Recent reports
        recent_reports = EReport.query.order_by(EReport.created_at.desc()).limit(5).all()
        
        return render_template('dashboard/driver_dashboard.html', 
                             stats=stats, 
                             recent_reports=recent_reports)
    
    elif current_user.is_finance():
        # Finance stats
        total_verifications = Verification.query.count()
        total_realizations = Realization.query.count()
        pending_verifications = Verification.query.filter_by(is_realized=False).count()
        completed_realizations = Realization.query.filter_by(is_verified=True).count()
        
        stats = {
            'total_verifications': total_verifications,
            'total_realizations': total_realizations,
            'pending': pending_verifications,
            'completed': completed_realizations
        }
        
        # Recent verifications
        recent_verifications = Verification.query.order_by(Verification.created_at.desc()).limit(5).all()
        
        # Recent realizations
        recent_realizations = Realization.query.order_by(Realization.created_at.desc()).limit(5).all()
        
        return render_template('dashboard/finance_dashboard.html',
                             stats=stats,
                             recent_verifications=recent_verifications,
                             recent_realizations=recent_realizations)
    
    else:
        # Unknown role
        return render_template('dashboard/default_dashboard.html')