from flask import Blueprint, render_template, request, redirect, url_for, flash
from datetime import datetime

from ..extensions import db
from ..models import Verification, Realization

from ..utils.helpers import create_pdf_header, create_info_table, create_pdf_response, create_notes_section, create_signature_section, format_idr

from flask_login import login_required, current_user
from ..utils.decorators import finance_required, finance_or_accounting_required


# ReportLab imports for PDF generation
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from io import BytesIO

realization_bp = Blueprint(
    "realization",
    __name__,
    url_prefix="/realization"
)


# =========================
# LIST REALIZATIONS
# =========================
@realization_bp.route("/")
@login_required
@finance_or_accounting_required
def list_realizations():
    realizations = Realization.query.order_by(Realization.created_at.desc()).all()
    return render_template("realization_list.html", realizations=realizations)

@realization_bp.route("/<int:id>")
@login_required
@finance_or_accounting_required
def detail(id):
    realization = Realization.query.get_or_404(id)
    return render_template(
        "realization_detail.html",
        realization=realization
    )


@realization_bp.route('/new/<int:verification_id>')
@login_required
@finance_required
def new(verification_id):
    """Show form to create new realization from verification"""
    verification = Verification.query.get_or_404(verification_id)
    
    # Check if verification already has realization
    if verification.realization:
        flash('Verification sudah memiliki realization!', 'warning')
        return redirect(url_for('realization.detail', id=verification.realization.id))
    
    # Check if verification is not realized yet
    if verification.is_realized:
        flash('Verification sudah direalisasi!', 'warning')
        return redirect(url_for('verification.detail', id=verification_id))
    
    # Pre-fill data
    today = datetime.now().date().isoformat()
    
    return render_template('realization.html', 
                         verification=verification,
                         today=today)



# =========================
# CREATE REALIZATION
# =========================
@realization_bp.route("/create", methods=["POST"])
@login_required
@finance_required
def create():
    """Create new realization"""
    try:
        verification_id = request.form.get('verification_id')
        verification = Verification.query.get_or_404(verification_id)
        
        # Check if verification already has realization
        if verification.realization:
            flash('Verification sudah memiliki realization!', 'error')
            return redirect(url_for('verification.detail', id=verification_id))
        
        # Parse date
        date_str = request.form.get('date')
        date = datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else datetime.now().date()
        
        # Get form data
        payment_method = request.form.get('payment_method')
        class_payment = request.form.get('class_payment')
        claim_amount = request.form.get('claim_amount')
        debit_no = request.form.get('debit_no')
        
        # Get numeric values
        realization_amount = float(request.form.get('realization_amount', 0) or 0)
        ppn = float(request.form.get('ppn', 0) or 0)
        total_amount = float(request.form.get('total_amount', 0) or 0)
        
        # Create realization
        realization = Realization(
            verification_id=verification.id,
            date=date,
            discrepancy_no=verification.discrepancy_no,
            working_order=verification.work_order,
            payment_method=payment_method,
            class_payment=class_payment,
            claim_amount=claim_amount,
            debit_no=debit_no,
            realization_amount=realization_amount,
            ppn=ppn,
            total_amount=total_amount,
            status='completed',
            is_verified=True
        )
        
        db.session.add(realization)
        
        # Update verification status
        verification.is_realized = True
        verification.status = 'realized'
        
        # Update E-Report status
        if verification.e_report:
            verification.e_report.realize_status = 'realized'
        
        db.session.commit()
        
        flash('Realization berhasil dibuat!', 'success')
        return redirect(url_for('realization.list_realizations'))
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error creating realization: {str(e)}', 'error')
        return redirect(url_for('verification.detail', id=verification_id))


# =========================
# DELETE REALIZATION
# =========================
@realization_bp.route("/delete/<int:id>", methods=["POST"])
@login_required
@finance_required
def delete(id):
    realization = Realization.query.get_or_404(id)

    verification = realization.verification
    verification.is_realized = False
    verification.e_report.realize_status = "unrealized"

    db.session.delete(realization)
    db.session.commit()

    flash("Realization deleted", "info")
    return redirect(url_for("realization.list_realizations"))

@realization_bp.route('/<int:id>/edit')
@login_required
@finance_required
def edit(id):
    """Show form to edit realization"""
    realization = Realization.query.get_or_404(id)
    return render_template('realization_edit.html', realization=realization)


@realization_bp.route('/<int:id>/update', methods=['POST'])
@login_required
@finance_required
def update(id):
    """Update realization"""
    try:
        realization = Realization.query.get_or_404(id)
        
        # Parse date
        date_str = request.form.get('date')
        realization.date = datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else realization.date
        
        # Update fields
        realization.payment_method = request.form.get('payment_method')
        realization.class_payment = request.form.get('class_payment')
        realization.claim_amount = request.form.get('claim_amount')
        realization.debit_no = request.form.get('debit_no')
        
        # Update numeric values
        realization.realization_amount = float(request.form.get('realization_amount', 0) or 0)
        realization.ppn = float(request.form.get('ppn', 0) or 0)
        realization.total_amount = float(request.form.get('total_amount', 0) or 0)
        
        realization.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        flash('Realization berhasil diupdate!', 'success')
        return redirect(url_for('realization.list_realizations'))
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating realization: {str(e)}', 'error')
        return redirect(url_for('realization.edit', id=id))

@realization_bp.route('/<int:id>/export-pdf')
@login_required
@finance_or_accounting_required
def export_pdf(id):
    try:
        realization = Realization.query.get_or_404(id)
        
        # Create PDF buffer and document
        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=2*cm,
            leftMargin=2*cm,
            topMargin=0.8*cm,
            bottomMargin=2*cm
        )
        
        elements = []
        styles = getSampleStyleSheet()
        normal_style = styles['Normal']
        normal_style.fontSize = 9
        
        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=11,
            textColor=colors.HexColor('#374151'),
            spaceAfter=10,
            spaceBefore=15
        )
        
        # Header
        elements.extend(create_pdf_header({
            'title': 'DISCREPANCY<br/>REALIZATION<br/>REPORT',
            'subtitle': 'Laporan Realisasi Ketidaksesuaian'
        }))
        
        # Report Date
        report_date_data = [[
            Paragraph(f'<b>Report Date / Tanggal Laporan:</b> {realization.date.strftime("%d %B %Y")}', normal_style)
        ]]
        report_date_table = Table(report_date_data, colWidths=[17*cm])
        report_date_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'RIGHT'),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#374151')),
        ]))
        elements.append(report_date_table)
        elements.append(Spacer(1, 0.5*cm))
        
        # Basic Information
        class_payment_labels = {
            'claim': 'Claim',
            'salary_deduction': 'Salary Deduction',
            'write_off': 'Write Off',
            'other': 'Other'
        }
        class_payment_display = class_payment_labels.get(realization.class_payment, realization.class_payment or '-')
        if realization.class_payment:
            class_payment_display = f'■ {class_payment_display}'

        info_data = [
            ['Customer', realization.verification.customer if realization.verification else '-'],
            ['Discrepancy No.', realization.discrepancy_no or '-'],
            ['Work Order', realization.working_order],
            ['Classification Payment', class_payment_display]
        ]
        
        elements.append(create_info_table(info_data))
        elements.append(Spacer(1, 0.5*cm))
        
        # Financial Details
        elements.append(Paragraph('<b>Financial Details / Rincian Keuangan</b>', heading_style))
        
        financial_data = [
    ['Claim Charge Amount', format_idr(realization.claim_amount, '-')],
    ['No. Debit Note (from Customer)', realization.debit_no or 'DR-2024-xxx'],
    ['Realization Amount', format_idr(realization.realization_amount)],
    ['PPN (11%)', format_idr(realization.ppn)],
]

        financial_table = create_info_table(financial_data, colWidths=[6*cm, 11*cm])
        financial_table.setStyle(TableStyle([
            ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ]))
        elements.append(financial_table)
        elements.append(Spacer(1, 0.3*cm))

# Total Amount
        total_data = [[
            Paragraph('<b>TOTAL AMOUNT</b>', normal_style),
            Paragraph(
                f"<b>{format_idr(realization.total_amount)}</b>",
                ParagraphStyle(
                    'TotalAmount',
                    fontSize=11,
                    textColor=colors.HexColor('#0891b2'),
                    alignment=1
                )
            )
        ]]

        
        total_table = Table(total_data, colWidths=[6*cm, 11*cm])
        total_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f0f9ff')),
            ('FONTSIZE', (0, 0), (-1, -1), 11),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#374151')),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#0891b2')),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
            ('LEFTPADDING', (0, 0), (-1, -1), 10),
            ('RIGHTPADDING', (0, 0), (-1, -1), 10),
            ('TOPPADDING', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ]))
        
        elements.append(total_table)
        elements.append(Spacer(1, 0.5*cm))
        
        # Notes
        notes_text = "Realisasi claim telah disesuaikan dengan debit note dari customer. Total amount termasuk PPN 11% sesuai ketentuan perpajakan yang berlaku."
        elements.extend(create_notes_section(notes_text, normal_style))
        elements.append(Spacer(1, 1*cm))
        
        # Signature
        elements.append(create_signature_section())
        
        # Build PDF
        doc.build(elements)
        
        return create_pdf_response(buffer, f'Realization_{realization.discrepancy_no}.pdf')
        
    except Exception as e:
        flash(f'Error generating PDF: {str(e)}', 'error')
        return redirect(url_for('realization.detail', id=id))