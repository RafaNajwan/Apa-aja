from flask import Blueprint, jsonify
from ..models import EReport

api_bp = Blueprint("api", __name__, url_prefix="/api")

@api_bp.route("/e-reports")
def get_reports():
    return jsonify([r.to_dict() for r in EReport.query.all()])
