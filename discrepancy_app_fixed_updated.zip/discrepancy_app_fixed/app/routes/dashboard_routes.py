from flask import Blueprint, render_template
from flask_login import login_required, current_user
from ..models.ereport import EReport
from ..models.verification import Verification
from ..models.realization import Realization
from ..extensions import db

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/dashboard')
@login_required
def index():
    """Dashboard - Simple stats without ownership"""
    
    stats = {}
    recent_reports = []
    
    if current_user.is_driver():
        # Driver Stats - Basic counts
        stats['total_reports'] = EReport.query.count()
        stats['verified'] = EReport.query.filter_by(is_verified=True).count()
        stats['unverified'] = EReport.query.filter_by(is_verified=False).count()
        
        # Recent reports (all)
        recent_reports = EReport.query.order_by(EReport.date.desc()).limit(5).all()
    
    elif current_user.is_finance():
        # Finance Stats
        stats['total_reports'] = EReport.query.count()
        stats['unverified'] = EReport.query.filter_by(is_verified=False).count()
        stats['total_verifications'] = Verification.query.count()
        stats['total_realizations'] = Realization.query.count()
        
        # Recent unverified reports
        recent_reports = EReport.query.filter_by(is_verified=False)\
            .order_by(EReport.date.desc()).limit(5).all()
    
    elif current_user.is_accounting():
    # Accounting Stats
        stats['total_reports'] = EReport.query.count()
        stats['verified'] = EReport.query.filter_by(is_verified=True).count()
        stats['total_verifications'] = Verification.query.count()
        stats['total_realizations'] = Realization.query.count()
        
        # ✅ CORRECT: Order by date instead
        recent_reports = EReport.query.filter_by(is_verified=True)\
            .order_by(EReport.date.desc())\
            .limit(5).all()
    
    return render_template('dashboard.html', 
                         stats=stats, 
                         recent_reports=recent_reports)