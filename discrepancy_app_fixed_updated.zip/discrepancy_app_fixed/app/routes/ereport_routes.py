from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
import os
from ..models import EReport, EReportItem
from ..extensions import db
from ..services.file_service import save_file
from ..services.pdf_service import generate_ereport_pdf
from datetime import datetime
from ..utils.helpers import create_pdf_header, create_info_table, create_pdf_response
from flask_login import login_required, current_user
from ..utils.decorators import driver_required, finance_or_accounting_required

# ReportLab imports for PDF generation
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from io import BytesIO

ereport_bp = Blueprint("ereport", __name__)


@ereport_bp.route("/<int:id>")
@login_required
def detail(id):
    report = EReport.query.get_or_404(id)
    return render_template("ereport_detail.html", report=report)


@ereport_bp.route("/e-report/new", methods=["GET"])
@login_required
@driver_required
def ereport_new():
    return render_template("report.html")


@ereport_bp.route("/e-report")
@login_required
def list_reports():
    from sqlalchemy import extract

    bulan = request.args.get("bulan", "")
    tahun = request.args.get("tahun", "")
    customer = request.args.get("customer", "")

    query = EReport.query

    if bulan:
        query = query.filter(extract("month", EReport.date) == int(bulan))
    if tahun:
        query = query.filter(extract("year", EReport.date) == int(tahun))
    if customer:
        query = query.filter(EReport.customer == customer)

    reports = query.order_by(EReport.created_at.desc()).all()

    # Data untuk dropdown filter
    all_reports = EReport.query.all()
    years = sorted(set(r.date.year for r in all_reports), reverse=True) or [datetime.now().year]
    customers = sorted(set(r.customer for r in all_reports if r.customer))

    return render_template(
        "ereport_list.html",
        reports=reports,
        years=years,
        customers=customers,
        selected_bulan=bulan,
        selected_tahun=tahun,
        selected_customer=customer,
    )


@ereport_bp.route("/e-report/create", methods=["POST"])
@login_required
@driver_required
def create():
    file = request.files.get("evidence")
    evidence = save_file(file)
    date_str = request.form['date']
    date = datetime.strptime(date_str, '%Y-%m-%d').date()

    detail_barangs = request.form.getlist("detail_barang[]")
    jumlahs = request.form.getlist("jumlah[]")
    items = []
    total_quantity = 0
    for db_val, j_val in zip(detail_barangs, jumlahs):
        db_val = db_val.strip()
        j_val = j_val.strip()
        if db_val and j_val:
            qty = int(j_val)
            total_quantity += qty
            items.append(EReportItem(detail_barang=db_val, jumlah=qty))

    report = EReport(
        date=date,
        customer=request.form.get("customer"),
        work_order=request.form["work_order"],
        quantity=total_quantity,
        deskripsi=request.form.get('deskripsi'),
        evidence=evidence
    )

    db.session.add(report)
    db.session.flush()

    for item in items:
        item.ereport_id = report.id
        db.session.add(item)

    db.session.commit()

    flash("E-Report berhasil dibuat!", "success")
    return redirect(url_for("ereport.list_reports"))


@ereport_bp.route('/edit_ereport/<int:id>')
@login_required
@driver_required
def edit(id):
    e_report = EReport.query.get_or_404(id)
    return render_template('ereport_edit.html', report=e_report)


@ereport_bp.route("/update/<int:id>", methods=["POST"])
@login_required
@driver_required
def update(id):
    report = EReport.query.get_or_404(id)

    str_date = request.form['date']

    report.customer = request.form.get("customer")
    report.work_order = request.form["work_order"]
    report.deskripsi = request.form.get("deskripsi")
    report.date = datetime.strptime(str_date, '%Y-%m-%d').date()

    EReportItem.query.filter_by(ereport_id=report.id).delete()
    detail_barangs = request.form.getlist("detail_barang[]")
    jumlahs = request.form.getlist("jumlah[]")
    total_quantity = 0
    for db_val, j_val in zip(detail_barangs, jumlahs):
        db_val = db_val.strip()
        j_val = j_val.strip()
        if db_val and j_val:
            qty = int(j_val)
            total_quantity += qty
            db.session.add(EReportItem(ereport_id=report.id, detail_barang=db_val, jumlah=qty))
    report.quantity = total_quantity

    file = request.files.get("evidence")
    if file and file.filename:
        report.evidence = save_file(file)

    report.updated_at = datetime.utcnow()

    db.session.commit()

    flash("E-Report berhasil diupdate!", "success")
    return redirect(url_for("ereport.list_reports"))


@ereport_bp.route("/delete/<int:id>", methods=["POST"])
@login_required
@driver_required
def delete(id):
    report = EReport.query.get_or_404(id)

    db.session.delete(report)
    db.session.commit()

    flash("E-Report deleted!", "info")
    return redirect(url_for("ereport.list_reports"))


@ereport_bp.route("/e-report/<int:id>/export-pdf")
@login_required
def export_pdf(id):
    try:
        e_report = EReport.query.get_or_404(id)

        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=2*cm,
            leftMargin=2*cm,
            topMargin=0.8*cm,
            bottomMargin=2*cm
        )

        elements = []
        styles = getSampleStyleSheet()
        normal_style = styles['Normal']
        normal_style.fontSize = 9

        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=11,
            textColor=colors.HexColor('#374151'),
            spaceAfter=10,
            spaceBefore=15
        )

        elements.extend(create_pdf_header({
            'title': 'E-REPORTING<br/>LAPANGAN',
            'subtitle': 'Field Report'
        }))

        customer = e_report.customer or '-'
        info_data = [
            ['Tanggal:', e_report.date.strftime('%d %B %Y')],
            ['Customer:', customer],
            ['Work Order:', e_report.work_order]
        ]

        elements.append(create_info_table(info_data))
        elements.append(Spacer(1, 0.5*cm))

        warning_title = Paragraph(
            '<b>⚠ LAPORAN SELISIH BARANG</b>',
            ParagraphStyle('WarningTitle', fontSize=11, textColor=colors.HexColor('#d97706'), spaceAfter=5)
        )

        if e_report.items:
            items_header = Paragraph(
                f'<b>Detail Barang / Item Details (Total: {e_report.quantity} pcs):</b>',
                ParagraphStyle('ItemsHeader', fontSize=9, textColor=colors.HexColor('#374151'), spaceAfter=4)
            )
            item_rows = [
                [Paragraph('<b>Detail Barang</b>', ParagraphStyle('TH', fontSize=8, textColor=colors.white)),
                 Paragraph('<b>Jumlah</b>', ParagraphStyle('TH2', fontSize=8, textColor=colors.white))]
            ]
            for it in e_report.items:
                item_rows.append([
                    Paragraph(it.detail_barang, ParagraphStyle('TD', fontSize=9, textColor=colors.HexColor('#374151'))),
                    Paragraph(str(it.jumlah), ParagraphStyle('TD2', fontSize=9, textColor=colors.HexColor('#374151'), alignment=1))
                ])
            detail_table = Table(item_rows, colWidths=[11*cm, 3.5*cm])
            detail_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0d9488')),
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f0fdfa')]),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#d1fae5')),
                ('ALIGN', (1, 0), (1, -1), 'CENTER'),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('LEFTPADDING', (0, 0), (-1, -1), 8),
                ('RIGHTPADDING', (0, 0), (-1, -1), 8),
                ('TOPPADDING', (0, 0), (-1, -1), 5),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ]))
            items_content = items_header
        else:
            items_content = Paragraph(
                f'<b>Jumlah Barang Kurang / Missing Items:</b><br/><font size="14"><b>{e_report.quantity} pcs</b></font>',
                ParagraphStyle('ItemsText', fontSize=9, textColor=colors.HexColor('#374151'), spaceAfter=10, leading=14)
            )
            detail_table = None

        explanation_title = Paragraph(
            '<b>Penjelasan / Explanation:</b>',
            ParagraphStyle('ExplanationTitle', fontSize=9, textColor=colors.HexColor('#374151'), spaceAfter=5)
        )

        explanation_text = Paragraph(
            e_report.deskripsi or '-',
            ParagraphStyle('ExplanationText', fontSize=9, textColor=colors.HexColor('#374151'), leading=12)
        )

        warning_content = [[warning_title], [items_content]]
        if detail_table:
            warning_content.append([detail_table])
        warning_content += [[explanation_title], [explanation_text]]
        warning_table = Table(warning_content, colWidths=[16*cm])
        warning_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#fef3c7')),
            ('LEFTPADDING', (0, 0), (-1, -1), 15),
            ('RIGHTPADDING', (0, 0), (-1, -1), 15),
            ('TOPPADDING', (0, 0), (0, 0), 12),
            ('TOPPADDING', (0, 1), (-1, 1), 8),
            ('TOPPADDING', (0, 2), (-1, 2), 8),
            ('TOPPADDING', (0, 3), (-1, 3), 5),
            ('BOTTOMPADDING', (0, 0), (0, 2), 5),
            ('BOTTOMPADDING', (0, 3), (0, 3), 12),
            ('LINEABOVE', (0, 0), (0, 0), 3, colors.HexColor('#f59e0b')),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))

        elements.append(warning_table)
        elements.append(Spacer(1, 0.5*cm))

        if e_report.evidence:
            elements.append(Paragraph('<b>Bukti Foto / Photo Evidence:</b>', heading_style))
            try:
                evidence_path = os.path.join('static', e_report.evidence)
                if os.path.exists(evidence_path):
                    evidence_img = Image(evidence_path, width=12*cm, height=9*cm, kind='proportional')
                    img_table = Table([[evidence_img]], colWidths=[17*cm])
                    img_table.setStyle(TableStyle([
                        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                    ]))
                    elements.append(img_table)
                else:
                    elements.append(Paragraph(
                        '<i>Bukti foto tidak tersedia</i>',
                        ParagraphStyle('NoImage', fontSize=9, textColor=colors.HexColor('#9ca3af'), alignment=1)
                    ))
            except Exception as img_error:
                elements.append(Paragraph(
                    f'<i>Error loading image: {str(img_error)}</i>',
                    ParagraphStyle('ImgError', fontSize=9, textColor=colors.red, alignment=1)
                ))
            elements.append(Spacer(1, 0.5*cm))

        elements.append(Spacer(1, 1*cm))
        elements.append(Paragraph(
            f'E-Reporting System | PT. Grahaprima Suksesamandiri Tbk<br/>Generated on {e_report.date.strftime("%d %B %Y")}',
            ParagraphStyle('Footer', fontSize=8, textColor=colors.HexColor('#9ca3af'), alignment=1)
        ))

        doc.build(elements)
        return create_pdf_response(buffer, f'EReport_{e_report.work_order}_{e_report.date.strftime("%Y%m%d")}.pdf')

    except Exception as e:
        flash(f'Error generating PDF: {str(e)}', 'error')
        return redirect(url_for('ereport.detail', id=id))
