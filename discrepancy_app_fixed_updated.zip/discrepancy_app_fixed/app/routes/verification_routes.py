from flask import Blueprint, render_template, redirect, url_for, flash, request, send_file
from datetime import datetime

from ..services.pdf_service import generate_verification_pdf
from ..extensions import db
from ..models import EReport, Verification

from ..utils.helpers import create_pdf_header, create_info_table, create_pdf_response, create_notes_section, create_signature_section, format_idr

from flask_login import login_required, current_user
from ..utils.decorators import finance_required, finance_or_accounting_required

# ReportLab imports for PDF generation
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from io import BytesIO

verification_bp = Blueprint(
    "verification",
    __name__,
    url_prefix="/verification"
)




# =========================
# LIST ALL VERIFICATIONS
# =========================
@verification_bp.route("/")
@login_required
@finance_or_accounting_required
def list_verifications():
    verifications = Verification.query.order_by(Verification.created_at.desc()).all()
    return render_template("verification_list.html", verifications=verifications)

@verification_bp.route("/<int:id>")
@login_required
@finance_or_accounting_required
def detail(id):
    verification = Verification.query.get_or_404(id)
    return render_template(
        "verification_detail.html",
        verification=verification
    )

@verification_bp.route("/new", methods=["GET"])
@login_required
@finance_required
def new():
    """Show form to create new verification"""
    
    ereport_id = request.args.get("ereport_id")
    e_report = None
    discrepancy_no = None
    today = datetime.now().strftime('%Y-%m-%d')

    if ereport_id:
        e_report = EReport.query.get_or_404(ereport_id)

        if e_report.is_verified:
            flash('E-Report sudah terverifikasi!', 'warning')
            return redirect(url_for('ereport.detail', id=ereport_id))

        discrepancy_no = Verification.generate_discrepancy_no(datetime.now().date())

    return render_template(
        "verification.html",
        e_report=e_report,
        discrepancy_no=discrepancy_no,
        today=today
    )



# =========================
# CREATE VERIFICATION
# =========================
@verification_bp.route("/create", methods=["POST"])
@login_required
@finance_required
def create():
    """Create new verification"""
    try:
        # Get form data
        e_report_id = request.form.get('e_report_id')
        date_str = request.form.get('date')
        customer = request.form.get('customer')
        discrepancy_no = request.form.get('discrepancy_no')
        work_order = request.form.get('work_order')
        license_num = request.form.get('license_num')
        driver_name = request.form.get('driver_name')
        remark = request.form.get('remark')
        claim_type = request.form.get('claim_type')
        item_name = request.form.get('item_name')
        quantity = request.form.get('quantity')
        unit_price = request.form.get('unit_price')
        loss = request.form.get('loss')
        total_price = request.form.get('total_price')
        
        # Validate required fields
        if not e_report_id or not date_str or not work_order:
            flash('E-Report ID, Date, and Work Order are required!', 'error')
            return redirect(url_for('verification.new'))
        
        # Get E-Report
        e_report = EReport.query.get_or_404(e_report_id)
        
        # Check if already verified
        if e_report.is_verified:
            flash('E-Report sudah terverifikasi!', 'warning')
            return redirect(url_for('ereport.detail', id=e_report_id))
        
        # Convert date
        date = datetime.strptime(date_str, '%Y-%m-%d').date()
        
        # Create verification
        verification = Verification(
            e_report_id=e_report.id,
            date=date,
            discrepancy_no=discrepancy_no,
            work_order=work_order,
            license_num=license_num,
            driver_name=driver_name,
            remark=remark,
            claim_type=claim_type,
            item_name=item_name,
            quantity=int(quantity) if quantity else None,
            unit_price=float(unit_price) if unit_price else None,
            loss=float(loss) if loss else None,
            total_price=float(total_price) if total_price else None,
            status='unrealized',
            is_realized=False
        )
        
        db.session.add(verification)
        
        # Update e_report status
        e_report.status = 'verified'
        e_report.is_verified = True
        
        db.session.commit()
        
        flash(f'Verification berhasil dibuat! Discrepancy No: {discrepancy_no}', 'success')
        return redirect(url_for('verification.list_verifications'))
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('verification.new', ereport_id=e_report_id))

@verification_bp.route("/edit/<int:id>")
@login_required
@finance_required
def edit(id):
    verification = Verification.query.get_or_404(id)

    return render_template(
        "verification_edit.html",
        verification=verification
    )

@verification_bp.route("/update/<int:id>", methods=["POST"])
@login_required
@finance_required
def update(id):
    verification = Verification.query.get_or_404(id)

    # Validate work_order (nullable=False)
    work_order = request.form.get("work_order")
    if not work_order:
        flash("Work Order tidak boleh kosong!", "error")
        return redirect(url_for("verification.edit", id=id))

    date = request.form.get("date")
    if date:
        verification.date = datetime.strptime(date, "%Y-%m-%d").date()

    verification.work_order = work_order
    verification.license_num = request.form.get("license_num")
    verification.driver_name = request.form.get("driver_name")
    verification.remark = request.form.get("remark")
    verification.claim_type = request.form.get("claim_type")
    verification.item_name = request.form.get("item_name")

    quantity = request.form.get("quantity")
    verification.quantity = int(quantity) if quantity else None

    unit_price = request.form.get("unit_price")
    verification.unit_price = float(unit_price) if unit_price else None

    loss = request.form.get("loss")
    verification.loss = float(loss) if loss else None

    total_price = request.form.get("total_price")
    verification.total_price = float(total_price) if total_price else None

    verification.updated_at = datetime.utcnow()

    db.session.commit()

    flash("Verification updated!", "success")
    return redirect(url_for("verification.list_verifications"))


# =========================
# MARK AS REALIZED
# =========================
@verification_bp.route("/mark-realized/<int:id>")
@login_required
@finance_required
def mark_realized(id):
    verification = Verification.query.get_or_404(id)

    verification.is_realized = True
    verification.e_report.realize_status = "realized"

    db.session.commit()

    flash("Marked as realized", "success")
    return redirect(url_for("verification.list_verifications"))


# =========================
# DELETE
# =========================
@verification_bp.route("/delete/<int:id>", methods=['POST'])
@login_required
@finance_required
def delete(id):
    verification = Verification.query.get_or_404(id)

    verification.e_report.is_verified = False
    verification.e_report.status = "pending"

    db.session.delete(verification)
    db.session.commit()

    flash("Verification deleted", "info")
    return redirect(url_for("verification.list_verifications"))

@verification_bp.route("/export-pdf/<int:id>")
@login_required
@finance_or_accounting_required
def export_pdf(id):
    """Export verification detail to PDF"""
    try:
        verification = Verification.query.get_or_404(id)
        
        # Create PDF buffer and document
        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=2*cm,
            leftMargin=2*cm,
            topMargin=0.8*cm,
            bottomMargin=2*cm
        )
        
        elements = []
        styles = getSampleStyleSheet()
        normal_style = styles['Normal']
        normal_style.fontSize = 9
        
        # Header
        elements.extend(create_pdf_header({
            'title': 'DISCREPANCY<br/>VERIFICATION<br/>REPORT',
            'subtitle': 'Laporan Verifikasi Ketidaksesuaian'
        }))
        
        # Report Date
        report_date_data = [[
            Paragraph(f'<b>Report Date / Tanggal Laporan:</b> {verification.date.strftime("%d %B %Y")}', normal_style)
        ]]
        report_date_table = Table(report_date_data, colWidths=[17*cm])
        report_date_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'RIGHT'),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#374151')),
        ]))
        elements.append(report_date_table)
        elements.append(Spacer(1, 0.5*cm))
        
        # Basic Information
        info_data = [
            ['Customer', verification.customer or '-'],
            ['Discrepancy No.', verification.discrepancy_no],
            ['Work Order', verification.work_order],
            ['Claim Type', f'⚠ {verification.claim_type.replace("_", " ").title()}' if verification.claim_type else '-']
        ]
        
        info_table = create_info_table(info_data)
        if verification.claim_type and 'rusak' in verification.claim_type.lower():
            info_table.setStyle(TableStyle([
                ('TEXTCOLOR', (1, 3), (1, 3), colors.red),
            ]))
        
        elements.append(info_table)
        elements.append(Spacer(1, 0.5*cm))
        
        # Item Details Table
        item_header = [['No.', 'Item Name', 'Qty', 'Unit Price', 'Total Amount']]
        item_data = [[
            '1',
            verification.item_name or '-',
            str(verification.quantity) + ' pcs' if verification.quantity else '-',
            format_idr(verification.unit_price),
            format_idr(verification.total_price)
        ]]
        total_row = [['', '', '', 'TOTAL CLAIM AMOUNT:', 
                     format_idr(verification.total_price)]]
        
        full_item_data = item_header + item_data + total_row
        item_table = Table(full_item_data, colWidths=[1.5*cm, 6*cm, 2*cm, 3.5*cm, 4*cm])
        item_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f3f4f6')),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor('#374151')),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('FONTSIZE', (0, 1), (-1, -2), 9),
            ('ALIGN', (0, 1), (0, -2), 'CENTER'),
            ('ALIGN', (2, 1), (2, -2), 'CENTER'),
            ('ALIGN', (3, 1), (-1, -2), 'RIGHT'),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#f9fafb')),
            ('FONTNAME', (3, -1), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, -1), (-1, -1), 9),
            ('ALIGN', (3, -1), (3, -1), 'RIGHT'),
            ('ALIGN', (4, -1), (4, -1), 'RIGHT'),
            ('TEXTCOLOR', (4, -1), (4, -1), colors.HexColor('#0891b2')),
            ('SPAN', (0, -1), (2, -1)),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e5e7eb')),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ]))
        
        elements.append(item_table)
        elements.append(Spacer(1, 0.5*cm))
        
        # Notes (if exists)
        if verification.remark:
            elements.extend(create_notes_section(verification.remark, normal_style))
            elements.append(Spacer(1, 1*cm))
        else:
            elements.append(Spacer(1, 1*cm))
        
        # Signature
        elements.append(create_signature_section())
        
        # Build PDF
        doc.build(elements)
        
        return create_pdf_response(buffer, f'Verification_{verification.discrepancy_no}.pdf')
        
    except Exception as e:
        flash(f'Error generating PDF: {str(e)}', 'error')
        return redirect(url_for('verification.detail', id=id))
