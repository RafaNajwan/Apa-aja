import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'change-this-in-production')
    SQLALCHEMY_DATABASE_URI = "sqlite:///discrepancy.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024

    UPLOAD_FOLDER = "static/uploads/evidence"
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "pdf"}
