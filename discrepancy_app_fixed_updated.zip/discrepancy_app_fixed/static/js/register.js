/* =============================================
   register.js — Register Page Scripts
   PT Graha Prima Sukses Mandiri
============================================= */

document.addEventListener('DOMContentLoaded', () => {

    /* -----------------------------------------
       PASSWORD VISIBILITY TOGGLE
    ----------------------------------------- */
    const togglePw = document.getElementById('togglePw');
    const pwInput  = document.getElementById('password');
    const eyeShow  = document.getElementById('eyeShow');
    const eyeHide  = document.getElementById('eyeHide');

    if (togglePw && pwInput) {
        togglePw.addEventListener('click', () => {
            const isHidden    = pwInput.type === 'password';
            pwInput.type      = isHidden ? 'text'  : 'password';
            eyeShow.style.display = isHidden ? 'none'  : 'block';
            eyeHide.style.display = isHidden ? 'block' : 'none';
            pwInput.focus();
        });
    }

    /* -----------------------------------------
       PASSWORD STRENGTH METER
    ----------------------------------------- */
    const pwStrengthBar   = document.getElementById('pwStrengthBar');
    const pwStrengthLabel = document.getElementById('pwStrengthLabel');

    function getStrength(pw) {
        if (!pw) return { level: '', label: '' };

        let score = 0;
        if (pw.length >= 6)  score++;
        if (pw.length >= 10) score++;
        if (/[A-Z]/.test(pw)) score++;
        if (/[0-9]/.test(pw)) score++;
        if (/[^A-Za-z0-9]/.test(pw)) score++;

        if (score <= 2) return { level: 'weak',   label: 'Weak' };
        if (score <= 3) return { level: 'medium',  label: 'Medium' };
        return              { level: 'strong',  label: 'Strong' };
    }

    if (pwInput && pwStrengthBar && pwStrengthLabel) {
        pwInput.addEventListener('input', () => {
            const { level, label } = getStrength(pwInput.value);

            // Reset classes
            pwStrengthBar.className   = 'pw-strength-bar';
            pwStrengthLabel.className = 'pw-strength-label';

            if (level) {
                pwStrengthBar.classList.add(level);
                pwStrengthLabel.classList.add(level);
                pwStrengthLabel.textContent = label;
            } else {
                pwStrengthLabel.textContent = '';
            }

            // Also re-check confirm match
            checkMatch();
        });
    }

    /* -----------------------------------------
       PASSWORD MATCH INDICATOR
    ----------------------------------------- */
    const pwConfirm    = document.getElementById('password_confirm');
    const pwMatchIcon  = document.getElementById('pwMatchIcon');

    function checkMatch() {
        if (!pwConfirm || !pwMatchIcon) return;
        const pw  = pwInput ? pwInput.value : '';
        const cfm = pwConfirm.value;

        if (!cfm) {
            pwMatchIcon.textContent = '';
            return;
        }

        if (pw === cfm) {
            pwMatchIcon.textContent = '✓';
            pwMatchIcon.style.color = '#27ae60';
        } else {
            pwMatchIcon.textContent = '✗';
            pwMatchIcon.style.color = '#e74c3c';
        }
    }

    if (pwConfirm) {
        pwConfirm.addEventListener('input', checkMatch);
    }

    /* -----------------------------------------
       ROLE CARD SELECTION
    ----------------------------------------- */
    const roleCards = document.querySelectorAll('.role-card');

    roleCards.forEach(card => {
        card.addEventListener('click', () => {
            // Deselect all
            roleCards.forEach(c => c.classList.remove('is-selected'));
            // Select clicked
            card.classList.add('is-selected');
            // Check the hidden radio inside
            const radio = card.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
        });

        // Support keyboard activation (Space/Enter on focused label)
        card.addEventListener('keydown', (e) => {
            if (e.key === ' ' || e.key === 'Enter') {
                e.preventDefault();
                card.click();
            }
        });
    });

    /* -----------------------------------------
       FORM VALIDATION ON SUBMIT
    ----------------------------------------- */
    const form = document.getElementById('registerForm');

    if (form) {
        form.addEventListener('submit', (e) => {
            const pw  = pwInput  ? pwInput.value  : '';
            const cfm = pwConfirm ? pwConfirm.value : '';
            const roleChecked = document.querySelector('input[name="role"]:checked');

            // Password length
            if (pw.length < 6) {
                e.preventDefault();
                showInlineError(pwInput, 'Password must be at least 6 characters.');
                pwInput.focus();
                return;
            }

            // Password match
            if (pw !== cfm) {
                e.preventDefault();
                showInlineError(pwConfirm, 'Passwords do not match.');
                pwConfirm.focus();
                return;
            }

            // Role selected
            if (!roleChecked) {
                e.preventDefault();
                const roleGroup = document.querySelector('.role-selector');
                if (roleGroup) {
                    roleGroup.style.outline = '2px solid #e74c3c';
                    roleGroup.style.borderRadius = '12px';
                    setTimeout(() => {
                        roleGroup.style.outline = '';
                    }, 2000);
                }
                return;
            }
        });
    }

    /* -----------------------------------------
       HELPER — INLINE ERROR
    ----------------------------------------- */
    function showInlineError(inputEl, message) {
        if (!inputEl) return;

        // Remove any existing error for this field
        const existing = inputEl.parentElement.parentElement.querySelector('.inline-error');
        if (existing) existing.remove();

        const err = document.createElement('span');
        err.className   = 'pw-strength-label weak inline-error';
        err.textContent = message;
        err.style.display = 'block';

        inputEl.parentElement.insertAdjacentElement('afterend', err);

        // Highlight border
        inputEl.style.borderColor = '#e74c3c';
        inputEl.addEventListener('input', () => {
            inputEl.style.borderColor = '';
            err.remove();
        }, { once: true });
    }

});