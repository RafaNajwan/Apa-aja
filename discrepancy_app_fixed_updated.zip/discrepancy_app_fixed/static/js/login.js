/* =============================================
   login.js — Login Page Scripts
   PT Graha Prima Sukses Mandiri
============================================= */

document.addEventListener('DOMContentLoaded', () => {

    /* -----------------------------------------
       Password Visibility Toggle
    ----------------------------------------- */
    const togglePw = document.getElementById('togglePw');
    const pwInput  = document.getElementById('password');
    const eyeShow  = document.getElementById('eyeShow');
    const eyeHide  = document.getElementById('eyeHide');

    if (togglePw && pwInput) {
        togglePw.addEventListener('click', () => {
            const isHidden = pwInput.type === 'password';

            pwInput.type          = isHidden ? 'text'  : 'password';
            eyeShow.style.display = isHidden ? 'none'  : 'block';
            eyeHide.style.display = isHidden ? 'block' : 'none';

            // Return focus to the input after toggling
            pwInput.focus();
        });
    }

});