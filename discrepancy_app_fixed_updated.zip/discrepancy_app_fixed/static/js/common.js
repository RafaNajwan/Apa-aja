/**
 * Common JavaScript Functions
 * Reusable functions across all pages
 */

// ============================================
// NAVBAR & NAVIGATION
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    // Navbar Toggle (Mobile Menu)
    const sidebarToggle = document.getElementById('sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            const navbarCenter = document.querySelector('.navbar-center');
            if (navbarCenter) {
                navbarCenter.classList.toggle('active');
            }
            
            // Toggle hamburger animation
            this.classList.toggle('active');
        });
    }

    // Account Dropdown Toggle
    const accountDropdown = document.querySelector('.account-dropdown');
    if (accountDropdown) {
        const dropdownBtn = accountDropdown.querySelector('.dropdown-btn');
        
        dropdownBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            accountDropdown.classList.toggle('active');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!accountDropdown.contains(e.target)) {
                accountDropdown.classList.remove('active');
            }
        });
    }

    // Highlight active menu
    const currentPath = window.location.pathname;
    document.querySelectorAll('.nav-menu-link').forEach(function(link) {
        if (link.getAttribute('href') === currentPath) {
            // Remove active from all links
            document.querySelectorAll('.nav-menu-link').forEach(l => l.classList.remove('active'));
            // Add active to current link
            link.classList.add('active');
        }
    });
});


// ============================================
// SIDEBAR (if exists)
// ============================================

// Sidebar submenu toggle
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.nav-item.has-submenu > .nav-link').forEach(function(link) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            this.parentElement.classList.toggle('open');
        });
    });
});


// ============================================
// FILE UPLOAD HELPERS
// ============================================

/**
 * Show selected filename and file size
 * @param {HTMLInputElement} input - File input element
 * @param {string} targetId - ID of element to show filename (default: 'file-name')
 */
function showFileName(input, targetId = 'file-name') {
    const fileName = input.files[0]?.name;
    const fileSize = input.files[0]?.size;
    const fileNameDisplay = document.getElementById(targetId);
    
    if (!fileNameDisplay) return;
    
    if (fileName) {
        const sizeMB = (fileSize / (1024 * 1024)).toFixed(2);
        fileNameDisplay.textContent = `Selected: ${fileName} (${sizeMB} MB)`;
        fileNameDisplay.style.color = '#059669';
        fileNameDisplay.style.fontWeight = '500';
        
        // Check file size (default max 5MB)
        const maxSize = input.dataset.maxSize ? parseInt(input.dataset.maxSize) : 5 * 1024 * 1024;
        if (fileSize > maxSize) {
            const maxSizeMB = (maxSize / (1024 * 1024)).toFixed(0);
            fileNameDisplay.textContent = `File too large! Max ${maxSizeMB}MB. Selected: ${fileName} (${sizeMB} MB)`;
            fileNameDisplay.style.color = '#dc2626';
            input.value = ''; // Clear the input
        }
    } else {
        fileNameDisplay.textContent = input.dataset.placeholder || 'No file selected';
        fileNameDisplay.style.color = '#6b7280';
        fileNameDisplay.style.fontWeight = 'normal';
    }
}


// ============================================
// FORM CALCULATION HELPERS
// ============================================

/**
 * Calculate total price (Quantity × Unit Price)
 * @param {string} qtyId - ID of quantity input
 * @param {string} priceId - ID of unit price input
 * @param {string} totalId - ID of total price input
 */
function calculateTotal(qtyId = 'quantity', priceId = 'unit_price', totalId = 'total_price') {
    const quantity = parseFloat(document.getElementById(qtyId)?.value) || 0;
    const unitPrice = parseFloat(document.getElementById(priceId)?.value) || 0;
    const totalPrice = quantity * unitPrice;
    const totalPriceInput = document.getElementById(totalId);
    
    if (!totalPriceInput) return;
    
    totalPriceInput.value = totalPrice.toFixed(2);
    
    // Visual feedback
    if (totalPrice > 0) {
        totalPriceInput.style.background = '#d1fae5';
        totalPriceInput.style.color = '#065f46';
    } else {
        totalPriceInput.style.background = '#e0f2fe';
        totalPriceInput.style.color = '#0369a1';
    }
}


// ============================================
// CONFIRMATION DIALOGS
// ============================================

/**
 * Confirm delete action
 * @param {string} message - Confirmation message
 * @returns {boolean}
 */
function confirmDelete(message = 'Are you sure you want to delete this item?') {
    return confirm(message);
}


// ============================================
// FLASH MESSAGE AUTO-DISMISS
// ============================================

/**
 * Auto-dismiss flash messages after timeout
 * @param {number} timeout - Timeout in milliseconds (default: 5000)
 */
function autoDismissAlerts(timeout = 5000) {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(function() {
                alert.remove();
            }, 500);
        }, timeout);
    });
}

// Auto-dismiss on page load
document.addEventListener('DOMContentLoaded', function() {
    // Uncomment to enable auto-dismiss
    // autoDismissAlerts(5000);
});


// ============================================
// NUMBER FORMATTING
// ============================================

/**
 * Format number with thousand separators
 * @param {number} num - Number to format
 * @returns {string}
 */
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * Format currency
 * @param {number} amount - Amount to format
 * @param {string} currency - Currency symbol (default: 'Rp')
 * @returns {string}
 */
function formatCurrency(amount, currency = 'Rp') {
    return `${currency} ${formatNumber(amount.toFixed(2))}`;
}


// ============================================
// DATE HELPERS
// ============================================

/**
 * Format date to DD/MM/YYYY
 * @param {Date|string} date - Date to format
 * @returns {string}
 */
function formatDate(date) {
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
}

/**
 * Get today's date in YYYY-MM-DD format (for input[type="date"])
 * @returns {string}
 */
function getTodayDate() {
    const today = new Date();
    return today.toISOString().split('T')[0];
}


// ============================================
// FORM VALIDATION
// ============================================

/**
 * Validate required fields
 * @param {string[]} fieldIds - Array of field IDs to validate
 * @returns {boolean}
 */
function validateRequired(fieldIds) {
    let isValid = true;
    fieldIds.forEach(function(fieldId) {
        const field = document.getElementById(fieldId);
        if (field && !field.value.trim()) {
            field.style.borderColor = '#ef4444';
            isValid = false;
        } else if (field) {
            field.style.borderColor = '#d1d5db';
        }
    });
    return isValid;
}


// ============================================
// LOADING SPINNER
// ============================================

/**
 * Show loading spinner
 * @param {string} targetId - ID of element to show spinner in
 */
function showLoading(targetId) {
    const target = document.getElementById(targetId);
    if (target) {
        target.innerHTML = '<div class="spinner"></div>';
    }
}

/**
 * Hide loading spinner
 * @param {string} targetId - ID of element containing spinner
 * @param {string} content - Content to replace spinner with
 */
function hideLoading(targetId, content = '') {
    const target = document.getElementById(targetId);
    if (target) {
        target.innerHTML = content;
    }
}


// ============================================
// EXPORT FUNCTIONS (for use in inline scripts)
// ============================================

// Make functions globally available
window.showFileName = showFileName;
window.calculateTotal = calculateTotal;
window.confirmDelete = confirmDelete;
window.formatNumber = formatNumber;
window.formatCurrency = formatCurrency;
window.formatDate = formatDate;
window.getTodayDate = getTodayDate;
window.validateRequired = validateRequired;
window.showLoading = showLoading;
window.hideLoading = hideLoading;